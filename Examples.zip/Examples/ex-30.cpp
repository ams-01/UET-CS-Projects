#include <iostream>
using namespace std;
int main()
{
    int num;
    double height;
    string name;
    cout << "Enter num: ";
    cin >> num; 
    cout<<"num: "<<num<<endl;
    cout<<"Enter the first name: "; 
    cin>>name;cout<<endl; 
    cout <<"Enter the height: ";
    cin>>height; cout<<endl;
    cout<<"Name: "<<name<<endl;cout<<"Height: "<<height; 
    cout <<endl;
}