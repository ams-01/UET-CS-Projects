#include<iostream>
using namespace std;
main(){
    int num1, num2;
    string name;
    cout<<"Enter number 1"<<endl;
    cin>>num1;
    cout<<"Enter number 2"<<endl;
    cin>>num2;
    cout<<"Enter your name"<<name<<endl;
    cin>>name;
    cout<<"Num1 is:"<<num1<<endl;
    cout<<"Num2 is:"<<num2<<endl;
    cout<<"Name is:"<<name<<endl;
}