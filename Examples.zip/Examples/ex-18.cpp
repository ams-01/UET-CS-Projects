#include<iostream>
using namespace std;
main (){
    string firstname, midname, lastname;
    cout<<"Enter first, middle and last name separate with spaces"<<endl;
    cin>>firstname >>midname >>lastname;
    cout<<"First name is:"<<firstname<<endl<<"Middle name is:"<<midname<<endl<<"last name is:"<<lastname<<endl;
}   