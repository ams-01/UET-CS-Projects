#include<iostream>
using namespace std;
main(){
    cout<<"5+9-1="<<5+9-1<<endl;
    cout<<"2+3*9="<<2+3*9<<endl;
    cout<<"25%4="<<25%4<<endl;
}