#include<iostream>
using namespace std;
main(){
    cout<<"5+7="<<5+7<<endl;
    cout<<"10-7="<<10-7<<endl;
    cout<<"8*9="<<8*9<<endl;
    cout<<"50/5="<<50/5<<endl;
    cout<<"98%5="<<98%5<<endl;
}