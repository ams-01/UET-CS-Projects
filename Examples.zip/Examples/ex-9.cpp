#include <iostream>
using namespace std;
int main()
{
cout << "static_cast<int>(8.9) = "
     << static_cast<int>(8.9)
     << endl;
cout << "static_cast<int>(5.2) = "
     << static_cast<int>(5.2)
     << endl;
cout << "static_cast<double>(25) = "
     << static_cast<double>(25)
     << endl;
cout << "static_cast<double>(9+8) = "
     << static_cast<double>(9+8)
     << endl;
cout << "static_cast<double>(15) / 2 = "
     << static_cast<double>(15) / 2
     << endl;
cout << "static_cast<double>(19 / 2) = "
     << static_cast<double>(19 / 2)
     << endl;
cout << "static_cast<int>(7.8 + static_cast<double>(15) / 2) = "
     << static_cast<int>(7.8 + static_cast<double>(15) / 2)
     << endl;
}