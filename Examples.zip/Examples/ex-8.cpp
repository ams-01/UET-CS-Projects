#include<iostream>
using namespace std;
main(){
    cout<<"5+9-8="<<5+9-8<<endl;
    cout<<"8*7/2="<<8*7/2<<endl;
    cout<<"9%2+4"<<9%2+4<<endl;
}