#include<iostream>
using namespace std;
main(){
    int a,b;
    float x,y;
    string c;
    a=5+9;
    b=9*8;
    x=9/8;
    y=78%3;
    c="Ahmad";
    cout<<"a is:"<<a<<endl;
    cout<<"b is:"<<b<<endl;
    cout<<"x is:"<<x<<endl;
    cout<<"y is:"<<y<<endl;
    cout<<"c is:"<<c<<endl;
}