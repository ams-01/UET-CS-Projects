#include<iostream>
using namespace std;
main(){
    float lenght, width,area,perimeter;
    cout<<"Area and Perimeter "<<endl;
    lenght= 8.5;
    width=9.2;
    perimeter=2*(lenght+width);
    area= lenght*width;
    cout<<"Area is"<<area<<endl;
    cout<<"Perimeter is"<<perimeter<<endl;

}