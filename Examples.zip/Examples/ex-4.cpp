#include<iostream>
using namespace std;
main(){
    float feets,reminches;
    int inches;
    cout<<"enter inches"<<endl;
    cin>>inches;
    feets=inches/12;
    reminches=inches %12;
    cout<<"Inches in Feets are"<<feets<<endl;
    cout<<"Remaining Inches are"<<reminches<<endl;
}